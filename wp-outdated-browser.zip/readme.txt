=== WP Outdated Browser ===
Contributors: deblynprado
Tags: Browser, Outdated, Message Outdated
Requires at least: 3.0.0
Tested up to: 3.9.1
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Show a message if the user is using an outdated browser.

== Description ==
This plugin is a version of [Outdated Browser Projetct](http://outdatedbrowser.com/) created by [Bürocratik](https://github.com/burocratik).

## What does it do? ##
This is a plugin to check if your user is using the lastest version of a browser.

== Installation ==
* Upload the \"WP Outdated Browser\" directory to the \"/wp-content/plugins/\" directory
* Activate the plugin through the \"Plugins\" menu in WordPress

== Frequently Asked Questions ==
= What does happen if my user is using an updated browser? = 
Nothing! This plugin just works if your using a outdated browser.

== Changelog ==
1.0.0 - 28/06/2014
* First version