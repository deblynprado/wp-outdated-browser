outdatedBrowser({
   bgColor: outOptions.bkgColor,
   color: outOptions.fontColor,
   lowerThan: outOptions.browser
})

console.log(outdatedBrowser);